=== Tell a Friend ===
Contributors: FreeTellaFriend.com
Donate link: http://www.freetellafriend.com/
Tags: social, bookmark, bookmarks, post, posts, link, links, page, pages, network, technorati, del.icio.us, digg, reddit, google, yahoo, facebook, permalink, url, button, media, plugin, bulgaria, bulgarian,tell,friend,addressbook,hotmail,gmail,yahoo,mail,share,
Requires at least: 2.0.0
Tested up to: 2.5
Stable tag: 0.1

Adds a 'Share This Post' button after each post. The share botton supports e-mail address book, social bookmarks and favorites.

== Description ==

Adds a 'Share This Post' button after each post. The service which is used is freetellafriend.com which supports e-mail address book, social bookmarks and favorites.

Abit about freetellafriend.com:

FreeTellaFriend is a free service to allow your visitors to share your website with their friends. The idea is simple; you place a 'tell a friend' button on your website, and when your visitor decides to tell their friend about your website, they click this button which then presents them with a straightforward form to e-mail their friends.

The great addition to FreeTellaFriend is your visitor can enter their e-mail username and password (we support major e-mail providers) and our system will automatically retrieve their contact list. Thereafter they can choose who to e-mail the website to. If one user decides to e-mail all their contacts, your website will be exposed to over 50 friends (on average).

The following is supported: Tell a Friend, Social Bookmarking and Add to Favorites.

== Installation ==

1. Upload the folder `/tell-a-friend/` to your WP plugin folder `/wp-content/plugins/` directory
1. The path must look like this: `/wp-content/plugins/tell-a-friend/`
1. Activate the plugin through the 'Plugins' menu in WordPress admin
1. You are ready, check the 'share this post' button after your posts.

Thanks for installing!

== Frequently Asked Questions ==
= What e-mails do you support? =
Our system supports all major e-mail providers. This includes:

    * MSN Hotmail
    * Windows Live
    * Yahoo! Mail
    * Gmail (Google Mail)
    * AOL Mail
    * Lycos Mail
    * Mail.com
= What social bookmarking do you support? =
We support all major social bookmarking wbesites. This includes:

    * Digg
    * Yahoo! Bookmarks
    * Live Favorites
    * Google Bookmarks
    * StumbleUpon
    * Del.icio.us

== Screenshots ==

1. How to activate the plugin.
2. 'Share This Post' button shown after every post.
3. The Tell a Friend page the user is forwarded to.